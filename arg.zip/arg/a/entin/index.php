<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="CuqxbOlrByGaa5vsCxXOZVwUAN29OjMrdPEgs8BM">
	<title>Correo Argentino </title> <!-- Pymes por Empresas kb-132 -->
    <link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/backend/css/font-awesome.min.css" type="text/css" media="all" />
	<link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/front/css/font-awesome.css" type="text/css" media="all" />
    <link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/css/styles.css">
    <link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/css/app.css" type="text/css" media="all" />
    <link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/css/custom.css" type="text/css" media="all" />
	<link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/inicio/css/footer.css" type="text/css" media="all" />
	<!-- Include Bootstrap Datepicker -->
	<link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/css/datepicker.min.css" />
	<link href="https://www.correoargentino.com.ar/MiCorreo/public/css/app.css" rel="stylesheet">
    <!-- Header blade  -->
	<link rel="stylesheet" type="text/css" href="https://www.correoargentino.com.ar/MiCorreo/public/css/bootstrap-arrow-buttons.css">
	<script>
	var el_token = "CuqxbOlrByGaa5vsCxXOZVwUAN29OjMrdPEgs8BM";
	var la_url = "https://www.correoargentino.com.ar/MiCorreo/public";
	</script>
	<script src="https://www.correoargentino.com.ar/MiCorreo/public/js/jquery-3.2.1.min.js"></script>
	<script type="text/javascript" src="https://www.correoargentino.com.ar/MiCorreo/public/js/processes.js?v20200602"></script>
	<script type="text/javascript" src="https://www.correoargentino.com.ar/MiCorreo/public/js/validate.js"></script>
	<link rel="shortcut icon" href="https://www.correoargentino.com.ar/MiCorreo/public/img/favicon.png">     
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-139040736-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', "UA-139040736-1");
</script>
 
	<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5DJHRTT');</script>
<!-- End Google Tag Manager -->
 
	<script src='https://www.google.com/recaptcha/api.js' async defer></script>	
</head>
<script>
function clickhamburguesa(){
	if ( $('#app-navbar-collapse').css('display') == 'inline' ) {
			$('#app-navbar-collapse').css('display', 'none');					
	} else {
			$('#app-navbar-collapse').css('display', 'inline');
	}
}
function clickhamburguesa(){
	if ( $('#app-navbar-collapse').attr('aria-expanded') != undefined ) {
			$('.collapse').collapse('hide');
			$('#app-navbar-collapse').attr('aria-expanded', null);					
	} else {
			$('#app-navbar-collapse').collapse('show');
			$('#app-navbar-collapse').attr('aria-expanded', 'true');
	}
}
</script>
<style>
.bodyApp{background-color: #fff !important;}
.wcptitulo{
/*width:350px !important; */
height:50px;
margin-bottom:20px;
float:left;
}
.wcptitulo h5{
margin-bottom: 2px;
margin-top: 1px;
padding-top: 5px;
}
</style>
</head>
<body class="bodyApp" >
	<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5DJHRTT"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
 
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top *topbackimagen"  style="border-top: solid 4px #152663;/*border-bottom: solid 4px #165394;*/ background: #ffcf17; padding-bottom:4px;" >             <svg  version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg" >
	<symbol viewBox="0 0 79.374992 79.226487" id="icono-pagar">
  <defs
     id="defs2" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.90509668"
     inkscape:cx="269.81312"
     inkscape:cy="100.25854"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1"
     showgrid="false"
     inkscape:window-width="1149"
     inkscape:window-height="716"
     inkscape:window-x="69"
     inkscape:window-y="72"
     inkscape:window-maximized="0"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0" />
  <metadata
     id="metadata5">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Capa 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(192.60801,-289.59021)">
    <path
       d="m -183.28723,368.28826 c -2.24571,-0.97785 -2.32768,0.44429 1.94478,-33.73965 3.80977,-30.48203 3.91651,-31.19667 4.7902,-32.07036 l 0.8936,-0.8936 h 22.73813 22.73813 l 0.89486,0.89486 c 0.87478,0.87478 0.98308,1.59552 4.82605,32.11528 3.55559,28.23751 3.88375,31.31935 3.43469,32.25593 -0.27308,0.56953 -0.89338,1.23625 -1.37845,1.4816 -1.3315,0.67349 -59.33048,0.63151 -60.88199,-0.0441 z m 55.60328,-6.64319 c 0.007,-0.24253 -1.46132,-12.38678 -3.2632,-26.9872 l -3.27615,-26.54623 -18.60903,-3e-4 c -10.23496,-1.6e-4 -18.60902,0.0397 -18.60902,0.0887 0,0.2973 -6.38285,51.48509 -6.55434,52.56313 l -0.21046,1.32291 h 25.25462 c 19.9616,0 25.25734,-0.0924 25.26758,-0.44097 z m -26.2115,-8.97535 c -0.75331,-0.19646 -1.6709,-1.86974 -1.6709,-3.04697 0,-0.61954 -0.2934,-0.97819 -1.05996,-1.29571 -0.58298,-0.24148 -1.54778,-0.99465 -2.14401,-1.67372 -1.22423,-1.39432 -1.19669,-2.62256 0.0831,-3.70547 1.00838,-0.85326 2.06789,-0.77256 3.47365,0.26458 1.66034,1.22495 3.29183,1.17217 4.61325,-0.14925 2.36499,-2.36499 0.42951,-5.67158 -3.31979,-5.67158 -1.57867,0 -3.94928,-1.28095 -5.30774,-2.868 -3.23029,-3.77386 -2.31566,-9.74963 1.89262,-12.36565 1.3719,-0.85281 1.72301,-1.28034 1.88838,-2.29934 0.27537,-1.69694 1.14698,-2.57535 2.55541,-2.57535 1.36759,0 2.61676,1.33583 2.61676,2.79828 0,0.74044 0.38812,1.19706 1.83362,2.15729 2.26386,1.50385 2.81436,2.78543 1.78906,4.16502 -0.96275,1.29544 -2.47962,1.3856 -4.15728,0.24711 -0.73026,-0.49556 -1.61562,-0.90103 -1.96747,-0.90103 -1.85139,0 -3.49515,1.74658 -3.49515,3.71378 0,1.28178 1.76594,2.989 3.0918,2.989 0.56617,0 1.75286,0.21773 2.63708,0.48384 4.45803,1.34167 6.84406,5.85072 5.55386,10.49555 -0.43912,1.58089 -2.77898,4.29575 -4.21508,4.8906 -0.77646,0.32162 -1.07044,0.67865 -1.07044,1.30005 0,1.72994 -1.54515,3.50674 -2.82222,3.24533 -0.097,-0.0199 -0.45636,-0.10912 -0.79854,-0.19836 z m -36.81358,-29.94778 c -0.60479,-0.29837 -1.27948,-0.93722 -1.4993,-1.41968 -0.27667,-0.60721 -0.39968,-5.26772 -0.39968,-15.14253 V 291.8944 l 1.0294,-1.1521 1.02939,-1.15209 h 37.6287 37.62871 l 1.0294,1.15209 1.02939,1.1521 v 14.48546 14.48546 l -1.0312,1.03119 c -1.42321,1.42322 -3.21717,1.42322 -4.64038,0 l -1.0312,-1.03119 V 308.49096 296.1166 h -32.98472 -32.98471 v 12.18835 c 0,13.47368 -0.0559,13.85152 -2.15859,14.58451 -1.38875,0.48412 -1.31481,0.48881 -2.64521,-0.16752 z"
       id="path4549"
       inkscape:connector-curvature="0" />
  </g>
  </symbol>
</svg>



<svg     version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"  >
 <symbol   viewBox="0 -256 1792 1792" id="icono-envio-cancelado">
  <g
     id="g4512">
    <g
       id="g3645"
       transform="matrix(1,0,0,-1,-30.372881,1224.678)">
      <path
         style="fill:currentColor"
         inkscape:connector-curvature="0"
         id="path3647"
         d="m 640,128 q 0,52 -38,90 -38,38 -90,38 -52,0 -90,-38 -38,-38 -38,-90 0,-52 38,-90 38,-38 90,-38 52,0 90,38 38,38 38,90 z M 256,640 H 640 V 896 H 482 q -13,0 -22,-9 L 265,692 q -9,-9 -9,-22 V 640 z M 1536,128 q 0,52 -38,90 -38,38 -90,38 -52,0 -90,-38 -38,-38 -38,-90 0,-52 38,-90 38,-38 90,-38 52,0 90,38 38,38 38,90 z m 256,1088 V 192 q 0,-15 -4,-26.5 -4,-11.5 -13.5,-18.5 -9.5,-7 -16.5,-11.5 -7,-4.5 -23.5,-6 -16.5,-1.5 -22.5,-2 -6,-0.5 -25.5,0 -19.5,0.5 -22.5,0.5 0,-106 -75,-181 -75,-75 -181,-75 -106,0 -181,75 -75,75 -75,181 H 768 q 0,-106 -75,-181 -75,-75 -181,-75 -106,0 -181,75 -75,75 -75,181 h -64 q -3,0 -22.5,-0.5 -19.5,-0.5 -25.5,0 -6,0.5 -22.5,2 Q 105,131 98,135.5 91,140 81.5,147 72,154 68,165.5 64,177 64,192 q 0,26 19,45 19,19 45,19 v 320 q 0,8 -0.5,35 -0.5,27 0,38 0.5,11 2.5,34.5 2,23.5 6.5,37 4.5,13.5 14,30.5 9.5,17 22.5,30 l 198,198 q 19,19 50.5,32 31.5,13 58.5,13 h 160 v 192 q 0,26 19,45 19,19 45,19 h 1024 q 26,0 45,-19 19,-19 19,-45 z" />
    </g>
    <path
       inkscape:connector-curvature="0"
       id="path4500"
       d="M 848.33638,735.98658 1567.8115,118.52656"
       style="fill:none;stroke:#ffffff;stroke-width:150;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;stroke-miterlimit:4;stroke-dasharray:none" />
    <path
       inkscape:connector-curvature="0"
       id="path4502"
       d="M 821.49029,70.2036 1535.5962,827.2633"
       style="fill:#ffffff;stroke:#ffffff;stroke-width:150;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1;stroke-miterlimit:4;stroke-dasharray:none" />
  </g>
  
  </symbol>
</svg>






<svg  version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg">
	 
<symbol id="icono-pinmap" viewBox="0 0 512 512">

<g>
	<path d="M256,0C167.641,0,96,71.625,96,160c0,24.75,5.625,48.219,15.672,69.125C112.234,230.313,256,512,256,512l142.594-279.375
		C409.719,210.844,416,186.156,416,160C416,71.625,344.375,0,256,0z M256,256c-53.016,0-96-43-96-96s42.984-96,96-96
		c53,0,96,43,96,96S309,256,256,256z"/>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
<g>
</g>
</symbol>
</svg>



<svg   version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"    >
     <symbol    viewBox="0 0 612 612"  id="icono-usuario-paquete">
     
<g
   id="g5113">
	<path
   d="m 251.733,288.168 c 79.576,0 144.084,-64.509 144.084,-144.084 C 395.817,64.509 331.31,0 251.733,0 172.158,0 107.649,64.509 107.649,144.084 c 0,79.575 64.509,144.084 144.084,144.084 z M 605.11562,606.49895 H 374.07147 v -219.1252 h 28.88052 28.88052 35.75683 v 80.68208 h 47.67578 v -80.68208 h 60.96998 28.88052 z M 352.98411,387.37375 c 1.414,39.206 0,143.48125 0,143.48125 0,0 -57.31511,5.733 -101.25111,5.733 C 112.806,536.588 44.82,513.887 19.895,502.796 13.464,499.936 8.282,491.754 8.282,484.714 V 437.22 c 0,-71.171 54.188,-130.214 123.333,-138.123 2.101,-0.241 5.216,0.659 6.929,1.899 31.881,23.08 70.912,36.854 113.19,36.854 42.278,0 81.31,-13.774 113.19,-36.854 1.713,-1.24 4.828,-2.14 6.93,-1.899 39.904,4.564 78.41537,34.2257 100.81537,65.3557 -2.482,1.222 -20.77563,0 -20.77563,0 h -98.90963 c 0,0 -0.42342,2.88935 0,22.92105 z"
   id="path5111"
   inkscape:connector-curvature="0"
   sodipodi:nodetypes="sssssccccccccccccccscssccscccccc" ></path>
</g>
<g
   id="g5115">
</g>
<g
   id="g5117">
</g>
<g
   id="g5119">
</g>
<g
   id="g5121">
</g>
<g
   id="g5123">
</g>
<g
   id="g5125">
</g>
<g
   id="g5127">
</g>
<g
   id="g5129">
</g>
<g
   id="g5131">
</g>
<g
   id="g5133">
</g>
<g
   id="g5135">
</g>
<g
   id="g5137">
</g>
<g
   id="g5139">
</g>
<g
   id="g5141">
</g>
<g
   id="g5143">
</g>
</symbol>
</svg>



<svg     version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"    >
     <symbol    viewBox="0 0 483.051 483.051" id="icono-toma-paquete">
     
<g
   id="g9">
	<g
   id="_x37_0_25_">
		<g
   id="g6">
			<circle
   cx="159.697"
   cy="83.459"
   r="83.459"
   id="circle2" />
			<path
   d="m 311.11759,122.80958 c -2.24395,-3.01349 -0.938,125.57095 -0.938,125.57095 v 0 L 270.756,285.885 c 0,0 -60.969,-67.929 -76.977,-82.275 -16.008,-14.346 -39.84,-24.049 -64.146,-24.049 -47.967,0 -89.123,35.537 -96.174,82.834 -0.121,0.682 -0.219,1.371 -0.285,2.069 l -0.01,0.113 c -0.291,2.274 -0.492,4.397 -0.617,6.461 l -9.363,185.718 c -0.641,6.734 1.588,13.432 6.143,18.434 4.553,5.006 11.002,7.859 17.771,7.859 h 134.336 c 12.186,0 22.441,-9.123 23.861,-21.229 l 9.713,-130.065 c 0.004,-0.039 0.01,-0.078 0.014,-0.119 l 0.201,-1.805 c 0,0 39.995,36.558 54.091,36.558 9.092,0 17.404,-3.113 23.612,-9.263 l 70.483,-69.819 c 5.81,1.375 118.61858,-1.96866 118.61858,-1.96866 V 122.80958 Z M 452.86031,250.22451 H 342.33169 v -95.68913 h 13.81607 27.3933 v 34.28434 h 21.70987 v -34.28434 h 19.97722 13.81608 13.81608 z"
   id="path4"
   inkscape:connector-curvature="0"
   sodipodi:nodetypes="ccccssccccccssccccsccccccccccccccccc" ></path>
		</g>
	</g>
</g>
<g
   id="g11">
</g>
<g
   id="g13">
</g>
<g
   id="g15">
</g>
<g
   id="g17">
</g>
<g
   id="g19">
</g>
<g
   id="g21">
</g>
<g
   id="g23">
</g>
<g
   id="g25">
</g>
<g
   id="g27">
</g>
<g
   id="g29">
</g>
<g
   id="g31">
</g>
<g
   id="g33">
</g>
<g
   id="g35">
</g>
<g
   id="g37">
</g>
<g
   id="g39">
</g>
</symbol>
</svg>


<svg version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"    >
<symbol viewBox="0 0 512 512" id="icono-moneda">
<path d="M256,32c123.5,0,224,100.5,224,224S379.5,480,256,480S32,379.5,32,256S132.5,32,256,32 M256,0C114.625,0,0,114.625,0,256
	s114.625,256,256,256s256-114.625,256-256S397.375,0,256,0L256,0z M256,64C149.938,64,64,149.938,64,256
	c0,106.031,85.938,192,192,192c106.031,0,192-85.969,192-192C448,149.938,362.031,64,256,64z M325.813,354.844
	c-12.594,14.125-30.781,22.438-54.563,24.938V416h-30.313v-36.031c-39.656-4.063-64.188-27.125-73.656-69.125l46.875-12.219
	c4.344,26.406,18.719,39.594,43.125,39.594c11.406,0,19.844-2.813,25.219-8.469s8.063-12.469,8.063-20.469
	c0-8.281-2.688-14.563-8.063-18.813c-5.375-4.281-17.344-9.688-35.875-16.25c-16.656-5.781-29.688-11.469-39.063-17.156
	c-9.375-5.625-17-13.531-22.844-23.688c-5.844-10.188-8.781-22.063-8.781-35.563c0-17.719,5.25-33.688,15.688-47.875
	c10.438-14.156,26.875-22.813,49.313-25.969V96h30.313v27.969c33.875,4.063,55.813,23.219,65.781,57.5l-41.75,17.125
	c-8.156-23.5-20.719-35.25-37.781-35.25c-8.563,0-15.438,2.625-20.594,7.875c-5.188,5.25-7.781,11.625-7.781,19.094
	c0,7.625,2.5,13.469,7.5,17.563c4.969,4.063,15.688,9.094,32.063,15.125c18,6.563,32.125,12.781,42.344,18.625
	c10.25,5.844,18.406,13.938,24.531,24.219c6.094,10.313,9.156,22.344,9.156,36.125C344.719,323.125,338.406,340.75,325.813,354.844z
	"/>
</symbol>	
</svg>

<svg  version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"    >
<symbol viewBox="0 0 512 512"  id="icono-bolsa-dinero">
	<g>
		<path d="M223.688,271.781v32c0,12.875,8.813,15.813,16,16h16v-64h-16C232.5,255.969,223.688,258.906,223.688,271.781z"/>
		<path d="M287.688,415.781h16.016c7.188-0.188,16-3.125,16-16v-32c0-12.875-8.813-15.813-16-16h-16.016V415.781z"/>
		<path d="M344.953,159.781h6.75c17.688,0,32-14.313,32-32c0-16.438-12.563-29.5-28.563-31.313l25.188-50.375
			c7.875-15.813,1.5-35-14.313-42.938c-15.813-7.875-35-1.5-42.938,14.313l-4.5,8.938c-2.625-15-15.125-26.625-30.891-26.625
			c-17.672,0-32,14.344-32,32c0-17.656-14.328-32-32-32c-15.766,0-28.266,11.625-30.906,26.625l-4.469-8.938
			c-7.922-15.781-27.078-22.25-42.938-14.313c-15.813,7.938-22.219,27.125-14.313,42.938l25.188,50.375
			c-15.984,1.813-28.563,14.875-28.563,31.313c0,17.688,14.313,32,32,32h6.734C87.156,217.594,31.688,340.125,31.688,417.938
			c0,104.656,100.281,93.5,224,93.5c123.703,0,224.016,11.156,224.016-93.5C479.703,340.125,424.203,217.594,344.953,159.781z
			 M303.703,319.781c19.313,0,48,12.781,48,48v32c0,35.219-28.688,48-48,48h-16.016v16c0,8.813-7.188,16-16,16s-16-7.188-16-16v-16
			h-48c-8.813,0-16-7.188-16-16s7.188-16,16-16h48v-64h-16c-19.313,0-48-12.781-48-48v-32c0-35.219,28.688-48,48-48h16v-16
			c0-8.813,7.188-16,16-16s16,7.188,16,16v16h48.016c8.813,0,16,7.188,16,16s-7.188,16-16,16h-48.016v64H303.703z"/>

	</g>
</symbol>
</svg>



<svg version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"     >
	 <symbol viewBox="0 0 100 100" id="icono-spinner">
	<g transform="rotate(0 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.9166666666666666s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(30 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.8333333333333334s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(60 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.75s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(90 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.6666666666666666s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(120 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.5833333333333334s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(150 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.5s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(180 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.4166666666666667s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(210 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.3333333333333333s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(240 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.25s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(270 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.16666666666666666s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(300 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="-0.08333333333333333s" repeatCount="indefinite"></animate>
  </rect>
</g><g transform="rotate(330 50 50)">
  <rect x="47" y="24" rx="9.4" ry="4.8" width="6" height="12" fill="#b8b8b8">
    <animate attributeName="opacity" values="1;0" times="0;1" dur="1s" begin="0s" repeatCount="indefinite"></animate>
  </rect>
</g>
</symbol>
</svg>




<svg     version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"    >
   <symbol     viewBox="0 0 59.763199 37.304668" id="icono-mionca">
   
   <metadata
     id="metadata5259"><rdf:RDF><cc:Work
         rdf:about=""><dc:format>image/svg+xml</dc:format><dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" /><dc:title></dc:title></cc:Work></rdf:RDF></metadata><defs
     id="defs5257"><clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath5269"><path
         d="M 0,27.978 H 44.822 V 0 H 0 Z"
         id="path5267"
         inkscape:connector-curvature="0" /></clipPath></defs><sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="1240"
     inkscape:window-height="875"
     id="namedview5255"
     showgrid="false"
     inkscape:zoom="5.1536733"
     inkscape:cx="30.151395"
     inkscape:cy="18.144756"
     inkscape:window-x="-7"
     inkscape:window-y="47"
     inkscape:window-maximized="0"
     inkscape:current-layer="g5261" /><g
     id="g5261"
     inkscape:groupmode="layer"
     inkscape:label="iconos"
     transform="matrix(1.3333333,0,0,-1.3333333,0,37.304667)"><g
       id="g5263"><g
         id="g5265"
         clip-path="url(#clipPath5269)"><g
           id="g5271"
           transform="translate(40.3076,16.2031)"><path
             d="m 0,0 -5.644,4.675 c -0.142,0.118 -0.315,0.18 -0.504,0.18 h -6.638 v 2.838 c 0,0.434 -0.354,0.788 -0.788,0.788 H -33.65 c -0.433,0 -0.788,-0.354 -0.788,-0.788 V 1.924 c 0,-0.434 0.355,-0.788 0.788,-0.788 0.434,0 0.788,0.354 0.788,0.788 v 4.981 h 18.508 v -18.689 h -6.463 c -0.434,0 -0.789,-0.355 -0.789,-0.788 0,-0.434 0.355,-0.788 0.789,-0.788 h 9.624 c 0.433,0 0.788,0.354 0.788,0.788 0,0.433 -0.355,0.788 -0.788,0.788 h -1.585 V 3.279 h 6.353 l 5.14,-4.257 -0.055,-10.791 h -0.82 c -0.434,0 -0.788,-0.354 -0.788,-0.788 0,-0.433 0.354,-0.788 0.788,-0.788 h 1.6 c 0.434,0 0.788,0.347 0.788,0.781 l 0.063,11.95 C 0.283,-0.378 0.181,-0.149 0,0 m -34.423,-1.063 h 9.562 c 0.433,0 0.788,0.354 0.788,0.788 0,0.433 -0.355,0.788 -0.788,0.788 h -9.562 c -0.433,0 -0.788,-0.355 -0.788,-0.788 0,-0.434 0.355,-0.788 0.788,-0.788 m -1.608,-3.58 9.562,-0.055 c 0.433,0 0.788,0.346 0.796,0.781 0.008,0.441 -0.347,0.796 -0.781,0.796 l -9.561,0.055 h -0.007 c -0.434,0 -0.789,-0.347 -0.789,-0.781 -0.008,-0.441 0.347,-0.796 0.78,-0.796 m 8.75,-2.845 c 0,0.433 -0.355,0.788 -0.788,0.788 h -9.562 c -0.433,0 -0.788,-0.355 -0.788,-0.788 0,-0.434 0.355,-0.788 0.788,-0.788 h 9.562 c 0.433,0 0.788,0.346 0.788,0.788 m -3.996,-4.296 h -1.585 v 2.096 c 0,0.434 -0.354,0.789 -0.788,0.789 -0.433,0 -0.788,-0.355 -0.788,-0.789 v -2.884 c 0,-0.434 0.355,-0.788 0.788,-0.788 h 2.373 c 0.433,0 0.788,0.354 0.788,0.788 0,0.433 -0.355,0.788 -0.788,0.788 m 5.257,-4.548 c -1.087,0 -2.002,0.898 -2.002,1.971 0,1.072 0.915,1.97 2.002,1.97 1.072,0 1.939,-0.882 1.939,-1.97 0,-1.088 -0.867,-1.971 -1.939,-1.971 m 0,5.518 c -0.946,0 -1.844,-0.371 -2.522,-1.041 -0.678,-0.678 -1.057,-1.561 -1.057,-2.506 0,-0.947 0.371,-1.829 1.057,-2.507 0.686,-0.67 1.576,-1.04 2.522,-1.04 1.939,0 3.516,1.592 3.516,3.547 0,1.955 -1.577,3.547 -3.516,3.547 m 21.219,5.556 h -4.84 v 4.896 h 2.949 l 1.891,-1.702 z m -1.056,6.259 c -0.142,0.135 -0.331,0.205 -0.528,0.205 h -4.044 c -0.433,0 -0.788,-0.354 -0.788,-0.788 v -6.464 c 0,-0.433 0.355,-0.788 0.788,-0.788 h 6.416 c 0.434,0 0.788,0.355 0.788,0.788 v 4.328 c 0,0.22 -0.094,0.433 -0.259,0.583 z m -0.914,-17.333 c -1.088,0 -2.002,0.898 -2.002,1.971 0,1.072 0.914,1.97 2.002,1.97 1.071,0 1.938,-0.882 1.938,-1.97 0,-1.088 -0.867,-1.971 -1.938,-1.971 m 0,5.518 c -0.946,0 -1.845,-0.371 -2.522,-1.041 -0.679,-0.678 -1.057,-1.561 -1.057,-2.506 0,-0.947 0.371,-1.829 1.057,-2.507 0.685,-0.67 1.576,-1.04 2.522,-1.04 1.938,0 3.515,1.592 3.515,3.547 0,1.955 -1.577,3.547 -3.515,3.547"
             style="fill:#fabb2e;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path5273"
             inkscape:connector-curvature="0" /></g></g></g></g>
	</symbol>
             
 </svg>
             


<svg  version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"   >
	<symbol          viewBox="0 0 46.642799 32.465732" id="icono-comprobante">
<metadata
     id="metadata4491"><rdf:RDF><cc:Work
         rdf:about=""><dc:format>image/svg+xml</dc:format><dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" /><dc:title></dc:title></cc:Work></rdf:RDF></metadata><defs
     id="defs4489"><clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath4501"><path
         d="M 0,0.239 H 35.918 V 26.728 H 0 Z"
         id="path4499"
         inkscape:connector-curvature="0" /></clipPath></defs><sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="1178"
     inkscape:window-height="829"
     id="namedview4487"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:zoom="5.9644739"
     inkscape:cx="11.261847"
     inkscape:cy="10.973954"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="0"
     inkscape:current-layer="g4493" /><g
     id="g4493"
     inkscape:groupmode="layer"
     inkscape:label="iconos"
     transform="matrix(1.3333333,0,0,-1.3333333,-0.4478667,37.084731)"><g
       id="g4495"
       transform="matrix(0.98125223,0,0,0.9938479,0.00770348,2.4017192)"><g
         id="g4497"
         clip-path="url(#clipPath4501)"><g
           id="g4503"
           transform="translate(15.6288,5.3124)"><path
             d="m 0,0 c 0.559,0 1.014,-0.455 1.014,-1.015 0,-0.559 -0.455,-1.014 -1.014,-1.014 -0.29,0 -0.556,0.118 -0.751,0.332 -0.377,0.415 -1.019,0.445 -1.433,0.068 -0.415,-0.377 -0.445,-1.018 -0.068,-1.434 0.341,-0.375 0.768,-0.654 1.237,-0.82 v -0.176 c 0,-0.559 0.454,-1.014 1.015,-1.014 0.56,0 1.014,0.455 1.014,1.014 v 0.175 c 1.181,0.419 2.029,1.546 2.029,2.869 0,1.678 -1.365,3.043 -3.043,3.043 -0.56,0 -1.015,0.455 -1.015,1.015 0,0.56 0.455,1.015 1.015,1.015 0.267,0 0.518,-0.103 0.708,-0.288 C 1.109,3.378 1.751,3.386 2.143,3.786 2.535,4.187 2.527,4.829 2.126,5.221 1.805,5.534 1.426,5.769 1.014,5.914 V 6.087 C 1.014,6.646 0.56,7.102 0,7.102 -0.561,7.102 -1.015,6.646 -1.015,6.087 V 5.912 C -2.195,5.493 -3.043,4.366 -3.043,3.043 -3.043,1.365 -1.678,0 0,0"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4505"
             inkscape:connector-curvature="0" /></g><g
           id="g4507"
           transform="translate(21.7153,10.3847)"><path
             d="m 0,0 h 2.942 c 0.56,0 1.015,0.455 1.015,1.015 0,0.558 -0.455,1.014 -1.015,1.014 H 0 C -0.559,2.029 -1.014,1.573 -1.014,1.015 -1.014,0.455 -0.559,0 0,0"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4509"
             inkscape:connector-curvature="0" /></g><g
           id="g4511"
           transform="translate(28.7158,10.3847)"><path
             d="M 0,0 C 0.56,0 1.014,0.455 1.014,1.015 1.014,1.573 0.56,2.029 0,2.029 -0.56,2.029 -1.015,1.573 -1.015,1.015 -1.015,0.455 -0.56,0 0,0"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4513"
             inkscape:connector-curvature="0" /></g><g
           id="g4515"
           transform="translate(21.7158,6.3271)"><path
             d="m 0,0 h 1.319 c 0.56,0 1.014,0.454 1.014,1.014 0,0.56 -0.454,1.014 -1.014,1.014 H 0 C -0.56,2.028 -1.015,1.574 -1.015,1.014 -1.015,0.454 -0.561,0 0,0"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4517"
             inkscape:connector-curvature="0" /></g><g
           id="g4519"
           transform="translate(30.8461,8.3554)"><path
             d="m 0,0 h -3.753 c -0.56,0 -1.015,-0.454 -1.015,-1.015 0,-0.559 0.455,-1.013 1.015,-1.013 H 0 c 0.561,0 1.015,0.454 1.015,1.013 C 1.015,-0.454 0.561,0 0,0"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4521"
             inkscape:connector-curvature="0" /></g><g
           id="g4523"
           transform="translate(21.7158,2.2685)"><path
             d="m 0,0 h 4.565 c 0.56,0 1.015,0.454 1.015,1.015 0,0.56 -0.455,1.014 -1.015,1.014 H 0 C -0.56,2.029 -1.015,1.575 -1.015,1.015 -1.015,0.454 -0.561,0 0,0"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4525"
             inkscape:connector-curvature="0" /></g><g
           id="g4527"
           transform="translate(30.8461,4.2978)"><path
             d="m 0,0 h -0.507 c -0.56,0 -1.014,-0.454 -1.014,-1.015 0,-0.56 0.454,-1.014 1.014,-1.014 H 0 c 0.561,0 1.015,0.454 1.015,1.014 C 1.015,-0.454 0.561,0 0,0"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4529"
             inkscape:connector-curvature="0" /></g><g
           id="g4531"
           transform="translate(33.3339,-25.0977)"><path
             d="M 0,0 -0.781,2.915 12.938,6.591 13.719,3.676 Z M -22.778,5.114 V 39.54 h 16.232 c 0.561,0 1.015,0.455 1.015,1.015 v 3.044 h 3.043 c 0.561,0 1.015,0.454 1.015,1.014 0,0.56 -0.454,1.014 -1.015,1.014 h -2.868 c 0.418,1.182 1.546,2.029 2.868,2.029 0.813,0 1.577,-0.316 2.152,-0.891 0.575,-0.576 0.892,-1.34 0.892,-2.152 V 20.196 l -4.928,4.737 c -0.573,0.569 -1.335,0.883 -2.144,0.883 -0.812,0 -1.577,-0.317 -2.151,-0.891 -0.575,-0.575 -0.892,-1.339 -0.892,-2.153 0,-0.812 0.317,-1.577 0.892,-2.151 l 5.705,-5.707 c 0.271,-0.33 3.018,-3.801 3.937,-9.428 L -0.414,5.114 Z m -8.116,36.455 v 3.044 c 0,1.678 1.366,3.043 3.044,3.043 H -6.543 C -7.181,46.808 -7.56,45.754 -7.56,44.613 V 41.569 Z M -7.233,22.056 c -0.191,0.191 -0.297,0.446 -0.297,0.716 0,0.271 0.106,0.526 0.297,0.717 0.192,0.193 0.446,0.298 0.717,0.298 0.271,0 0.526,-0.105 0.718,-0.298 0.004,-0.004 0.92,-0.884 0.92,-0.884 l -1.41,-1.495 z m 9.201,-5.175 c 0.374,0.159 0.616,0.526 0.616,0.932 V 31.624 C 4.23,29.002 5.639,25.775 6.72,22.127 7.915,18.097 8.369,14.71 8.443,13.745 8.654,11.014 8.609,8.654 8.566,7.52 L 2.946,6.014 c -1.083,6.32 -4.245,10.079 -4.387,10.245 -0.017,0.019 -3.412,3.416 -3.412,3.416 l 1.437,1.524 4.283,-4.117 C 1.161,16.801 1.593,16.721 1.968,16.881 M 15.942,3.221 14.636,8.096 c -0.07,0.259 -0.24,0.481 -0.473,0.616 -0.233,0.135 -0.51,0.171 -0.77,0.101 L 10.615,8.068 c 0.033,1.309 0.038,3.414 -0.149,5.832 -0.254,3.3 -2.246,14.18 -7.881,21.234 v 9.479 c 0,1.355 -0.528,2.628 -1.486,3.586 -0.959,0.959 -2.232,1.487 -3.587,1.487 H -27.85 c -2.797,0 -5.073,-2.276 -5.073,-5.073 v -4.058 c 0,-0.56 0.455,-1.015 1.015,-1.015 h 7.101 V 4.1 c 0,-0.561 0.454,-1.015 1.015,-1.015 h 20.865 l 1.23,-4.59 c 0.07,-0.261 0.239,-0.481 0.472,-0.616 0.156,-0.09 0.331,-0.136 0.508,-0.136 0.088,0 0.176,0.011 0.262,0.034 l 15.679,4.202 c 0.542,0.145 0.863,0.701 0.718,1.242"
             style="fill:#2a5391;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4533"
             inkscape:connector-curvature="0" /></g></g></g></g>
             </symbol>
             </svg>












   




<svg  version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"  >
   <symbol    viewBox="0 0 27.945601 37.304668" id="icono-peso">
   <metadata
     id="metadata6417"><rdf:RDF><cc:Work
         rdf:about=""><dc:format>image/svg+xml</dc:format><dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" /><dc:title></dc:title></cc:Work></rdf:RDF></metadata><defs
     id="defs6415"><clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath6427"><path
         d="M 0,27.978 H 20.959 V 0 H 0 Z"
         id="path6425"
         inkscape:connector-curvature="0" /></clipPath></defs><sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="764"
     inkscape:window-height="480"
     id="namedview6413"
     showgrid="false"
     inkscape:zoom="6.326286"
     inkscape:cx="13.9728"
     inkscape:cy="18.652334"
     inkscape:window-x="139"
     inkscape:window-y="215"
     inkscape:window-maximized="0"
     inkscape:current-layer="g6419" /><g
     id="g6419"
     inkscape:groupmode="layer"
     inkscape:label="iconos"
     transform="matrix(1.3333333,0,0,-1.3333333,0,37.304667)"><g
       id="g6421"><g
         id="g6423"
         clip-path="url(#clipPath6427)"><g
           id="g6429"
           transform="translate(15.2959,9.5302)"><path
             d="M 0,0 C -0.117,0.398 -0.261,0.745 -0.428,1.039 -0.596,1.334 -0.836,1.622 -1.148,1.903 -1.461,2.185 -1.742,2.41 -1.991,2.583 -2.24,2.755 -2.583,2.947 -3.018,3.16 -3.452,3.374 -3.797,3.532 -4.051,3.637 -4.304,3.74 -4.672,3.883 -5.152,4.064 -5.578,4.228 -5.896,4.353 -6.104,4.438 -6.312,4.524 -6.586,4.646 -6.926,4.806 -7.266,4.964 -7.52,5.104 -7.687,5.227 -7.855,5.35 -8.034,5.499 -8.225,5.676 c -0.19,0.177 -0.324,0.364 -0.401,0.563 -0.076,0.199 -0.115,0.417 -0.115,0.654 0,0.615 0.272,1.119 0.816,1.508 0.543,0.39 1.246,0.584 2.107,0.584 0.381,0 0.768,-0.051 1.163,-0.156 0.393,-0.104 0.731,-0.222 1.012,-0.353 0.281,-0.131 0.546,-0.277 0.795,-0.435 0.25,-0.159 0.426,-0.279 0.531,-0.36 0.104,-0.082 0.17,-0.136 0.197,-0.163 0.118,-0.091 0.24,-0.123 0.367,-0.096 0.136,0.01 0.24,0.082 0.313,0.218 l 1.101,1.984 c 0.109,0.182 0.086,0.354 -0.068,0.518 -0.054,0.053 -0.122,0.117 -0.204,0.19 -0.081,0.072 -0.258,0.203 -0.531,0.394 -0.271,0.19 -0.559,0.36 -0.862,0.509 -0.305,0.15 -0.698,0.302 -1.184,0.456 -0.484,0.154 -0.985,0.258 -1.501,0.313 v 2.392 c 0,0.127 -0.041,0.232 -0.123,0.313 -0.082,0.082 -0.186,0.122 -0.313,0.122 H -6.96 c -0.118,0 -0.22,-0.043 -0.306,-0.129 -0.086,-0.086 -0.13,-0.187 -0.13,-0.306 v -2.447 c -1.422,-0.271 -2.578,-0.879 -3.465,-1.821 -0.889,-0.943 -1.333,-2.039 -1.333,-3.29 0,-0.372 0.039,-0.726 0.116,-1.061 0.076,-0.335 0.172,-0.636 0.285,-0.904 0.113,-0.268 0.274,-0.53 0.482,-0.788 0.209,-0.259 0.406,-0.481 0.592,-0.666 0.186,-0.186 0.428,-0.379 0.727,-0.578 0.3,-0.199 0.555,-0.361 0.768,-0.483 0.213,-0.122 0.496,-0.262 0.85,-0.421 0.353,-0.159 0.633,-0.279 0.836,-0.36 0.204,-0.082 0.483,-0.195 0.837,-0.34 0.489,-0.19 0.851,-0.338 1.088,-0.442 0.235,-0.104 0.534,-0.249 0.897,-0.435 0.362,-0.185 0.627,-0.355 0.795,-0.509 0.168,-0.155 0.319,-0.345 0.455,-0.572 0.137,-0.226 0.204,-0.466 0.204,-0.72 0,-0.716 -0.278,-1.269 -0.836,-1.659 -0.557,-0.389 -1.203,-0.585 -1.937,-0.585 -0.335,0 -0.67,0.037 -1.006,0.11 -1.178,0.235 -2.279,0.802 -3.304,1.699 l -0.026,0.027 c -0.082,0.1 -0.191,0.141 -0.327,0.122 -0.145,-0.018 -0.249,-0.072 -0.313,-0.163 l -1.4,-1.836 c -0.136,-0.18 -0.127,-0.366 0.027,-0.556 0.046,-0.055 0.125,-0.137 0.238,-0.245 0.114,-0.109 0.325,-0.279 0.632,-0.51 0.309,-0.232 0.644,-0.448 1.006,-0.653 0.363,-0.204 0.823,-0.406 1.381,-0.605 0.557,-0.199 1.135,-0.34 1.733,-0.421 v -2.379 c 0,-0.118 0.043,-0.219 0.129,-0.306 0.086,-0.086 0.188,-0.129 0.306,-0.129 h 1.835 c 0.127,0 0.231,0.041 0.313,0.122 0.082,0.082 0.123,0.185 0.123,0.313 v 2.379 c 1.441,0.236 2.612,0.854 3.514,1.856 0.902,1.002 1.353,2.195 1.353,3.582 C 0.178,-0.825 0.119,-0.399 0,0"
             style="fill:#6AA843;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path6431"
             inkscape:connector-curvature="0" /></g></g></g></g>
             
             </symbol>
             </svg>



<svg  version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"  >
  <symbol id="icono-activado"    viewBox="0 0 30.855707 18.692989">
  <defs
     id="defs4858" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.98994949"
     inkscape:cx="48.281828"
     inkscape:cy="21.597517"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:window-width="764"
     inkscape:window-height="421"
     inkscape:window-x="214"
     inkscape:window-y="495"
     inkscape:window-maximized="0" />
  <metadata
     id="metadata4861">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Capa 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(-47.647755,-35.351071)">
    <g
       id="g4543"
       transform="matrix(0.35277777,0,0,-0.35277777,69.158732,52.57721)">
      <path
         d="m 0,0 h -34.478 c -12.31,0 -22.331,10.021 -22.331,22.34 0,12.31 10.021,22.332 22.331,22.332 H 0 C 12.31,44.672 22.322,34.65 22.322,22.34 22.322,10.021 12.31,0 0,0 m 0,48.83 h -34.478 c -14.607,0 -26.498,-11.881 -26.498,-26.49 0,-14.616 11.891,-26.498 26.498,-26.498 H 0 c 14.608,0 26.489,11.882 26.489,26.498 0,14.609 -11.881,26.49 -26.489,26.49"
         style="  fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4545"
         inkscape:connector-curvature="0" />
    </g>
    <g
       id="g4547"
       transform="matrix(0.35277777,0,0,-0.35277777,56.995836,50.04229)">
      <path
         d="m 0,0 c -8.353,0 -15.146,6.793 -15.146,15.155 0,8.353 6.793,15.146 15.146,15.146 8.353,0 15.155,-6.793 15.155,-15.146 C 15.155,6.793 8.353,0 0,0 m 0,34.468 c -10.65,0 -19.313,-8.672 -19.313,-19.313 0,-10.651 8.663,-19.313 19.313,-19.313 10.651,0 19.322,8.662 19.322,19.313 0,10.641 -8.671,19.313 -19.322,19.313"
         style="  fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4549"
         inkscape:connector-curvature="0" />
    </g>
    <g
       id="g4551"
       transform="matrix(0.35277777,0,0,-0.35277777,73.221534,43.190535)">
      <path
         d="m 0,0 -11.489,-11.489 c -0.383,-0.383 -0.921,-0.611 -1.469,-0.611 -0.556,0 -1.075,0.219 -1.477,0.611 l -5.744,5.744 c -0.812,0.812 -0.812,2.134 0,2.946 0.401,0.392 0.921,0.611 1.477,0.611 0.556,0 1.076,-0.219 1.468,-0.611 l 4.276,-4.277 10.013,10.021 C -2.134,3.757 -0.812,3.757 0,2.945 0.812,2.134 0.812,0.812 0,0"
         style="  fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4553"
         inkscape:connector-curvature="0" />
    </g>
  </g>
  </symbol>
</svg>






<svg  version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"  >
   <symbol id="icono-desactivado"   viewBox="0 0 30.852533 18.69334">
  
  <defs
     id="defs4858" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.98994949"
     inkscape:cx="98.504607"
     inkscape:cy="76.116413"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:window-width="764"
     inkscape:window-height="421"
     inkscape:window-x="309"
     inkscape:window-y="497"
     inkscape:window-maximized="0" />
  <metadata
     id="metadata4861">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Capa 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(-34.359645,-49.77551)">
    <g
       id="g4527"
       transform="matrix(0.35277777,0,0,-0.35277777,55.867447,67.230249)">
      <path
         d="m 0,0 h -34.478 c -12.665,0 -22.969,10.304 -22.969,22.979 0,12.675 10.304,22.979 22.969,22.979 H 0 c 12.666,0 22.97,-10.304 22.97,-22.979 C 22.97,10.304 12.666,0 0,0 m 0,49.478 h -34.478 c -14.607,0 -26.489,-11.891 -26.489,-26.499 0,-14.608 11.882,-26.49 26.489,-26.49 H 0 c 14.608,0 26.489,11.882 26.489,26.49 0,14.608 -11.881,26.499 -26.489,26.499"
         style="fill:#555859;fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4529"
         inkscape:connector-curvature="0" />
    </g>
    <g
       id="g4531"
       transform="matrix(0.35277777,0,0,-0.35277777,55.867447,67.001824)">
      <path
         d="M 0,0 H -34.478 C -46.788,0 -56.8,10.021 -56.8,22.332 c 0,12.319 10.012,22.34 22.322,22.34 H 0 c 12.31,0 22.322,-10.021 22.322,-22.34 C 22.322,10.021 12.31,0 0,0 m 0,45.311 h -34.478 c -12.665,0 -22.969,-10.305 -22.969,-22.979 0,-12.675 10.304,-22.979 22.969,-22.979 H 0 c 12.666,0 22.97,10.304 22.97,22.979 C 22.97,35.006 12.666,45.311 0,45.311 M 0,0 H -34.478 C -46.788,0 -56.8,10.021 -56.8,22.332 c 0,12.319 10.012,22.34 22.322,22.34 H 0 c 12.31,0 22.322,-10.021 22.322,-22.34 C 22.322,10.021 12.31,0 0,0 m 0,45.311 h -34.478 c -12.665,0 -22.969,-10.305 -22.969,-22.979 0,-12.675 10.304,-22.979 22.969,-22.979 H 0 c 12.666,0 22.97,10.304 22.97,22.979 C 22.97,35.006 12.666,45.311 0,45.311 M 0,0 H -34.478 C -46.788,0 -56.8,10.021 -56.8,22.332 c 0,12.319 10.012,22.34 22.322,22.34 H 0 c 12.31,0 22.322,-10.021 22.322,-22.34 C 22.322,10.021 12.31,0 0,0 m 0,45.311 h -34.478 c -12.665,0 -22.969,-10.305 -22.969,-22.979 0,-12.675 10.304,-22.979 22.969,-22.979 H 0 c 12.666,0 22.97,10.304 22.97,22.979 0,12.674 -10.304,22.979 -22.97,22.979"
         style="fill:#555859;fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4533"
         inkscape:connector-curvature="0" />
    </g>
    <g
       id="g4535"
       transform="matrix(0.35277777,0,0,-0.35277777,55.867447,64.470222)">
      <path
         d="m 0,0 c -8.353,0 -15.155,6.803 -15.155,15.155 0,8.362 6.802,15.155 15.155,15.155 8.353,0 15.146,-6.793 15.146,-15.155 C 15.146,6.803 8.353,0 0,0 m 0,34.468 c -10.65,0 -19.322,-8.662 -19.322,-19.313 0,-10.65 8.672,-19.313 19.322,-19.313 10.65,0 19.313,8.663 19.313,19.313 0,10.651 -8.663,19.313 -19.313,19.313"
         style="fill:#555859;fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4537"
         inkscape:connector-curvature="0" />
    </g>
    <g
       id="g4539"
       transform="matrix(0.35277777,0,0,-0.35277777,43.93294,55.070597)">
      <path
         d="m 0,0 v -22.97 c 0,-1.149 -0.93,-2.088 -2.079,-2.088 -1.149,0 -2.079,0.939 -2.079,2.088 V 0 c 0,1.149 0.93,2.079 2.079,2.079 C -0.93,2.079 0,1.149 0,0"
         style="fill:#555859;fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4541"
         inkscape:connector-curvature="0" />
    </g>
  </g>
  
  </symbol>
</svg>





<svg version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"  >
 <symbol    viewBox="0 0 28.703411 15.247055" id="icono-ver">
  <defs
     id="defs5569" />
  <sodipodi:namedview
     id="base"
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1.0"
     inkscape:pageopacity="0.0"
     inkscape:pageshadow="2"
     inkscape:zoom="0.35"
     inkscape:cx="-16.732961"
     inkscape:cy="145.95619"
     inkscape:document-units="mm"
     inkscape:current-layer="layer1"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:window-width="764"
     inkscape:window-height="421"
     inkscape:window-x="110"
     inkscape:window-y="210"
     inkscape:window-maximized="0" />
  <metadata
     id="metadata5572">
    <rdf:RDF>
      <cc:Work
         rdf:about="">
        <dc:format>image/svg+xml</dc:format>
        <dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
        <dc:title></dc:title>
      </cc:Work>
    </rdf:RDF>
  </metadata>
  <g
     inkscape:label="Capa 1"
     inkscape:groupmode="layer"
     id="layer1"
     transform="translate(-30.249485,-51.251472)">
    <g
       id="g4559"
       transform="matrix(0.35277777,0,0,-0.35277777,45.722566,58.875423)">
      <path
         d="m 0,0 z m 0,0 c 0,-1.755 -1.424,-3.178 -3.179,-3.178 -1.755,0 -3.178,1.423 -3.178,3.178 0,1.755 1.423,3.178 3.178,3.178 C -1.424,3.178 0,1.755 0,0"
         style="   fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4561"
         inkscape:connector-curvature="0" />
    </g>
    <g
       id="g4563"
       transform="matrix(0.35277777,0,0,-0.35277777,44.60119,61.678702)">
      <path
         d="m 0,0 z m 0,0 c -4.382,0 -7.945,3.565 -7.945,7.945 0,4.382 3.563,7.946 7.945,7.946 4.381,0 7.945,-3.564 7.945,-7.946 C 7.945,3.565 4.381,0 0,0 m 0,20.659 c -7.01,0 -12.713,-5.703 -12.713,-12.714 0,-7.009 5.703,-12.713 12.713,-12.713 7.01,0 12.713,5.704 12.713,12.713 0,7.011 -5.703,12.714 -12.713,12.714"
         style="   fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4565"
         inkscape:connector-curvature="0" />
    </g>
    <g
       id="g4567"
       transform="matrix(0.35277777,0,0,-0.35277777,44.60119,64.816483)">
      <path
         d="M 0,0 Z M 0,0 C -13.862,0 -26.621,6.115 -35.283,16.842 -26.621,27.571 -13.862,33.685 0,33.685 13.861,33.685 26.62,27.571 35.283,16.842 26.62,6.114 13.861,0 0,0 M 40.208,18.271 C 35.637,24.397 29.635,29.474 22.851,32.953 15.736,36.603 8.049,38.452 0,38.452 c -8.049,0 -15.737,-1.849 -22.852,-5.498 -6.784,-3.48 -12.786,-8.557 -17.356,-14.683 l -0.474,-0.64 v -1.583 l 0.474,-0.635 C -35.638,9.288 -29.636,4.21 -22.851,0.731 -15.737,-2.918 -8.049,-4.768 0,-4.768 c 8.049,0 15.736,1.85 22.851,5.499 6.784,3.479 12.787,8.557 17.358,14.682 l 0.473,0.635 v 1.589 z"
         style="   fill-opacity:1;fill-rule:nonzero;stroke:none"
         id="path4569"
         inkscape:connector-curvature="0" />
    </g>
  </g>
  </symbol>
</svg>



<svg   version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"  >
  <symbol viewBox="-0.2 2.9 46.455225 23.95" id="icono-comprobante2">
	<metadata
     id="metadata4491"><rdf:RDF><cc:Work
         rdf:about=""><dc:format>image/svg+xml</dc:format><dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" /><dc:title></dc:title></cc:Work></rdf:RDF></metadata><defs
     id="defs4489"><clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath4501"><path
         d="M 0,0.239 H 35.918 V 26.728 H 0 Z"
         id="path4499"
         inkscape:connector-curvature="0" /></clipPath></defs><sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="1178"
     inkscape:window-height="829"
     id="namedview4487"
     showgrid="false"
     fit-margin-top="0"
     fit-margin-left="0"
     fit-margin-right="0"
     fit-margin-bottom="0"
     inkscape:zoom="5.9644739"
     inkscape:cx="10.961637"
     inkscape:cy="11.806732"
     inkscape:window-x="0"
     inkscape:window-y="0"
     inkscape:window-maximized="0"
     inkscape:current-layer="g4493"
     viewbox-width="46.36"
     viewbox-x="-0.2"
     viewbox-y="2.9"
     viewbox-height="23.95" /><g
     id="g4493"
     inkscape:groupmode="layer"
     inkscape:label="iconos"
     transform="matrix(1.3333333,0,0,-1.3333333,-0.74786668,35.122123)"><g
       id="g4495"
       transform="matrix(0.98125223,0,0,0.9938479,0.00770348,2.4017192)"><g
         id="g4497"
         clip-path="url(#clipPath4501)"><g
           id="g4503"
           transform="translate(15.6288,5.3124)"><path
             d="m 0,0 c 0.559,0 1.014,-0.455 1.014,-1.015 0,-0.559 -0.455,-1.014 -1.014,-1.014 -0.29,0 -0.556,0.118 -0.751,0.332 -0.377,0.415 -1.019,0.445 -1.433,0.068 -0.415,-0.377 -0.445,-1.018 -0.068,-1.434 0.341,-0.375 0.768,-0.654 1.237,-0.82 v -0.176 c 0,-0.559 0.454,-1.014 1.015,-1.014 0.56,0 1.014,0.455 1.014,1.014 v 0.175 c 1.181,0.419 2.029,1.546 2.029,2.869 0,1.678 -1.365,3.043 -3.043,3.043 -0.56,0 -1.015,0.455 -1.015,1.015 0,0.56 0.455,1.015 1.015,1.015 0.267,0 0.518,-0.103 0.708,-0.288 C 1.109,3.378 1.751,3.386 2.143,3.786 2.535,4.187 2.527,4.829 2.126,5.221 1.805,5.534 1.426,5.769 1.014,5.914 V 6.087 C 1.014,6.646 0.56,7.102 0,7.102 -0.561,7.102 -1.015,6.646 -1.015,6.087 V 5.912 C -2.195,5.493 -3.043,4.366 -3.043,3.043 -3.043,1.365 -1.678,0 0,0"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4505"
             inkscape:connector-curvature="0" /></g><g
           id="g4507"
           transform="translate(21.7153,10.3847)"><path
             d="m 0,0 h 2.942 c 0.56,0 1.015,0.455 1.015,1.015 0,0.558 -0.455,1.014 -1.015,1.014 H 0 C -0.559,2.029 -1.014,1.573 -1.014,1.015 -1.014,0.455 -0.559,0 0,0"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4509"
             inkscape:connector-curvature="0" /></g><g
           id="g4511"
           transform="translate(28.7158,10.3847)"><path
             d="M 0,0 C 0.56,0 1.014,0.455 1.014,1.015 1.014,1.573 0.56,2.029 0,2.029 -0.56,2.029 -1.015,1.573 -1.015,1.015 -1.015,0.455 -0.56,0 0,0"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4513"
             inkscape:connector-curvature="0" /></g><g
           id="g4515"
           transform="translate(21.7158,6.3271)"><path
             d="m 0,0 h 1.319 c 0.56,0 1.014,0.454 1.014,1.014 0,0.56 -0.454,1.014 -1.014,1.014 H 0 C -0.56,2.028 -1.015,1.574 -1.015,1.014 -1.015,0.454 -0.561,0 0,0"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4517"
             inkscape:connector-curvature="0" /></g><g
           id="g4519"
           transform="translate(30.8461,8.3554)"><path
             d="m 0,0 h -3.753 c -0.56,0 -1.015,-0.454 -1.015,-1.015 0,-0.559 0.455,-1.013 1.015,-1.013 H 0 c 0.561,0 1.015,0.454 1.015,1.013 C 1.015,-0.454 0.561,0 0,0"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4521"
             inkscape:connector-curvature="0" /></g><g
           id="g4523"
           transform="translate(21.7158,2.2685)"><path
             d="m 0,0 h 4.565 c 0.56,0 1.015,0.454 1.015,1.015 0,0.56 -0.455,1.014 -1.015,1.014 H 0 C -0.56,2.029 -1.015,1.575 -1.015,1.015 -1.015,0.454 -0.561,0 0,0"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4525"
             inkscape:connector-curvature="0" /></g><g
           id="g4527"
           transform="translate(30.8461,4.2978)"><path
             d="m 0,0 h -0.507 c -0.56,0 -1.014,-0.454 -1.014,-1.015 0,-0.56 0.454,-1.014 1.014,-1.014 H 0 c 0.561,0 1.015,0.454 1.015,1.014 C 1.015,-0.454 0.561,0 0,0"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4529"
             inkscape:connector-curvature="0" /></g><g
           id="g4531"
           transform="translate(33.3339,-25.0977)"><path
             d="M 0,0 -0.781,2.915 12.938,6.591 13.719,3.676 Z M -22.778,5.114 V 39.54 h 16.232 c 0.561,0 1.015,0.455 1.015,1.015 v 3.044 h 3.043 c 0.561,0 1.015,0.454 1.015,1.014 0,0.56 -0.454,1.014 -1.015,1.014 h -2.868 c 0.418,1.182 1.546,2.029 2.868,2.029 0.813,0 1.577,-0.316 2.152,-0.891 0.575,-0.576 0.892,-1.34 0.892,-2.152 V 20.196 l -4.928,4.737 c -0.573,0.569 -1.335,0.883 -2.144,0.883 -0.812,0 -1.577,-0.317 -2.151,-0.891 -0.575,-0.575 -0.892,-1.339 -0.892,-2.153 0,-0.812 0.317,-1.577 0.892,-2.151 l 5.705,-5.707 c 0.271,-0.33 3.018,-3.801 3.937,-9.428 L -0.414,5.114 Z m -8.116,36.455 v 3.044 c 0,1.678 1.366,3.043 3.044,3.043 H -6.543 C -7.181,46.808 -7.56,45.754 -7.56,44.613 V 41.569 Z M -7.233,22.056 c -0.191,0.191 -0.297,0.446 -0.297,0.716 0,0.271 0.106,0.526 0.297,0.717 0.192,0.193 0.446,0.298 0.717,0.298 0.271,0 0.526,-0.105 0.718,-0.298 0.004,-0.004 0.92,-0.884 0.92,-0.884 l -1.41,-1.495 z m 9.201,-5.175 c 0.374,0.159 0.616,0.526 0.616,0.932 V 31.624 C 4.23,29.002 5.639,25.775 6.72,22.127 7.915,18.097 8.369,14.71 8.443,13.745 8.654,11.014 8.609,8.654 8.566,7.52 L 2.946,6.014 c -1.083,6.32 -4.245,10.079 -4.387,10.245 -0.017,0.019 -3.412,3.416 -3.412,3.416 l 1.437,1.524 4.283,-4.117 C 1.161,16.801 1.593,16.721 1.968,16.881 M 15.942,3.221 14.636,8.096 c -0.07,0.259 -0.24,0.481 -0.473,0.616 -0.233,0.135 -0.51,0.171 -0.77,0.101 L 10.615,8.068 c 0.033,1.309 0.038,3.414 -0.149,5.832 -0.254,3.3 -2.246,14.18 -7.881,21.234 v 9.479 c 0,1.355 -0.528,2.628 -1.486,3.586 -0.959,0.959 -2.232,1.487 -3.587,1.487 H -27.85 c -2.797,0 -5.073,-2.276 -5.073,-5.073 v -4.058 c 0,-0.56 0.455,-1.015 1.015,-1.015 h 7.101 V 4.1 c 0,-0.561 0.454,-1.015 1.015,-1.015 h 20.865 l 1.23,-4.59 c 0.07,-0.261 0.239,-0.481 0.472,-0.616 0.156,-0.09 0.331,-0.136 0.508,-0.136 0.088,0 0.176,0.011 0.262,0.034 l 15.679,4.202 c 0.542,0.145 0.863,0.701 0.718,1.242"
             style="    fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path4533"
             inkscape:connector-curvature="0" /></g></g></g></g>
             </symbol>
             
             </svg>



<svg     version="1.1" style="position: absolute; width: 0; height: 0; overflow: hidden" xmlns="http://www.w3.org/2000/svg"    >
   <symbol     viewBox="0 0 59.763199 37.304668" id="icono-mionca-azul">
   
   <metadata
     id="metadata5259"><rdf:RDF><cc:Work
         rdf:about=""><dc:format>image/svg+xml</dc:format><dc:type
           rdf:resource="http://purl.org/dc/dcmitype/StillImage" /><dc:title></dc:title></cc:Work></rdf:RDF></metadata><defs
     id="defs5257"><clipPath
       clipPathUnits="userSpaceOnUse"
       id="clipPath5269"><path
         d="M 0,27.978 H 44.822 V 0 H 0 Z"
         id="path5267"
         inkscape:connector-curvature="0" /></clipPath></defs><sodipodi:namedview
     pagecolor="#ffffff"
     bordercolor="#666666"
     borderopacity="1"
     objecttolerance="10"
     gridtolerance="10"
     guidetolerance="10"
     inkscape:pageopacity="0"
     inkscape:pageshadow="2"
     inkscape:window-width="1240"
     inkscape:window-height="875"
     id="namedview5255"
     showgrid="false"
     inkscape:zoom="5.1536733"
     inkscape:cx="30.151395"
     inkscape:cy="18.144756"
     inkscape:window-x="-7"
     inkscape:window-y="47"
     inkscape:window-maximized="0"
     inkscape:current-layer="g5261" /><g
     id="g5261"
     inkscape:groupmode="layer"
     inkscape:label="iconos"
     transform="matrix(1.3333333,0,0,-1.3333333,0,37.304667)"><g
       id="g5263"><g
         id="g5265"
         clip-path="url(#clipPath5269)"><g
           id="g5271"
           transform="translate(40.3076,16.2031)"><path
             d="m 0,0 -5.644,4.675 c -0.142,0.118 -0.315,0.18 -0.504,0.18 h -6.638 v 2.838 c 0,0.434 -0.354,0.788 -0.788,0.788 H -33.65 c -0.433,0 -0.788,-0.354 -0.788,-0.788 V 1.924 c 0,-0.434 0.355,-0.788 0.788,-0.788 0.434,0 0.788,0.354 0.788,0.788 v 4.981 h 18.508 v -18.689 h -6.463 c -0.434,0 -0.789,-0.355 -0.789,-0.788 0,-0.434 0.355,-0.788 0.789,-0.788 h 9.624 c 0.433,0 0.788,0.354 0.788,0.788 0,0.433 -0.355,0.788 -0.788,0.788 h -1.585 V 3.279 h 6.353 l 5.14,-4.257 -0.055,-10.791 h -0.82 c -0.434,0 -0.788,-0.354 -0.788,-0.788 0,-0.433 0.354,-0.788 0.788,-0.788 h 1.6 c 0.434,0 0.788,0.347 0.788,0.781 l 0.063,11.95 C 0.283,-0.378 0.181,-0.149 0,0 m -34.423,-1.063 h 9.562 c 0.433,0 0.788,0.354 0.788,0.788 0,0.433 -0.355,0.788 -0.788,0.788 h -9.562 c -0.433,0 -0.788,-0.355 -0.788,-0.788 0,-0.434 0.355,-0.788 0.788,-0.788 m -1.608,-3.58 9.562,-0.055 c 0.433,0 0.788,0.346 0.796,0.781 0.008,0.441 -0.347,0.796 -0.781,0.796 l -9.561,0.055 h -0.007 c -0.434,0 -0.789,-0.347 -0.789,-0.781 -0.008,-0.441 0.347,-0.796 0.78,-0.796 m 8.75,-2.845 c 0,0.433 -0.355,0.788 -0.788,0.788 h -9.562 c -0.433,0 -0.788,-0.355 -0.788,-0.788 0,-0.434 0.355,-0.788 0.788,-0.788 h 9.562 c 0.433,0 0.788,0.346 0.788,0.788 m -3.996,-4.296 h -1.585 v 2.096 c 0,0.434 -0.354,0.789 -0.788,0.789 -0.433,0 -0.788,-0.355 -0.788,-0.789 v -2.884 c 0,-0.434 0.355,-0.788 0.788,-0.788 h 2.373 c 0.433,0 0.788,0.354 0.788,0.788 0,0.433 -0.355,0.788 -0.788,0.788 m 5.257,-4.548 c -1.087,0 -2.002,0.898 -2.002,1.971 0,1.072 0.915,1.97 2.002,1.97 1.072,0 1.939,-0.882 1.939,-1.97 0,-1.088 -0.867,-1.971 -1.939,-1.971 m 0,5.518 c -0.946,0 -1.844,-0.371 -2.522,-1.041 -0.678,-0.678 -1.057,-1.561 -1.057,-2.506 0,-0.947 0.371,-1.829 1.057,-2.507 0.686,-0.67 1.576,-1.04 2.522,-1.04 1.939,0 3.516,1.592 3.516,3.547 0,1.955 -1.577,3.547 -3.516,3.547 m 21.219,5.556 h -4.84 v 4.896 h 2.949 l 1.891,-1.702 z m -1.056,6.259 c -0.142,0.135 -0.331,0.205 -0.528,0.205 h -4.044 c -0.433,0 -0.788,-0.354 -0.788,-0.788 v -6.464 c 0,-0.433 0.355,-0.788 0.788,-0.788 h 6.416 c 0.434,0 0.788,0.355 0.788,0.788 v 4.328 c 0,0.22 -0.094,0.433 -0.259,0.583 z m -0.914,-17.333 c -1.088,0 -2.002,0.898 -2.002,1.971 0,1.072 0.914,1.97 2.002,1.97 1.071,0 1.938,-0.882 1.938,-1.97 0,-1.088 -0.867,-1.971 -1.938,-1.971 m 0,5.518 c -0.946,0 -1.845,-0.371 -2.522,-1.041 -0.679,-0.678 -1.057,-1.561 -1.057,-2.506 0,-0.947 0.371,-1.829 1.057,-2.507 0.685,-0.67 1.576,-1.04 2.522,-1.04 1.938,0 3.515,1.592 3.515,3.547 0,1.955 -1.577,3.547 -3.515,3.547"
             style="fill:#165394;fill-opacity:1;fill-rule:nonzero;stroke:none"
             id="path5273"
             inkscape:connector-curvature="0" /></g></g></g></g>
	</symbol>
             
 </svg>	
<link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/css/extras.css" type="text/css" media="all" />
<script>
//20180816GC
var tiempoFuera;
jQuery(document).ready(function(){
		
	$.ajaxSetup({    
	headers: {'X-CSRF-TOKEN': 'CuqxbOlrByGaa5vsCxXOZVwUAN29OjMrdPEgs8BM'}
	});
	$(".spMontoSaldo").html("");
	$(".spMontoSaldoCC").html(""); // add line kb-144
});
function clickhamburguesa(){
	if ( $('#app-navbar-collapse').attr('aria-expanded') != undefined ) {
			$('#app-navbar-collapse').collapse('hide');
			//$('.collapse').collapse('hide');
			$('#app-navbar-collapse').attr('aria-expanded', null);					
	} else {
			$('#app-navbar-collapse').collapse('show');
			$('#app-navbar-collapse').attr('aria-expanded', 'true');
	}
}
</script>
<div class="region region-leaderboard" style="background: #152663; color: #FFF; text-align: right;padding: 0 0;border-bottom: solid 4px #FFF;"> 	<div class="region-inner clearfix">
		<div id="block-block-1" class="block block-block no-title odd first last block-count-3 block-region-leaderboard block-1">
			<div class="block-inner clearfix">  
				<div class="block-content " style="color: #FFF;text-align: right;">
					<p>
					<a href="#" style="color: #FFF;text-decoration: none;font-size: 13px; font-family: Arial;font-weight:lighter;margin-right:15px">Preguntas Frecuentes</a>
					|
					<a href="#" style="color: #FFF;text-decoration: none;font-size: 13px; font-family: Arial;font-weight:lighter;margin-left:15px;margin-right:15px">Contacto</a>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>  
<div class="container" style="background: #ffcf17;width: 100%; height: 80px; margin-top: 10px;">         <div class="navbar-header" style="min-height: 68px;">
            <!-- Collapsed Hamburger -->
            <button id="btn-hamburguesa" type="button" class="navbar-toggle collapsed" data-toggle="" estado="" onclick="clickhamburguesa()" data-target="#app-navbar-collapse" style="border-color:transparent !important; background-color:transparent !important;" >
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar" style="background-color: #152663;height:3px"></span>                 <span class="icon-bar" style="background-color: #152663;height:3px"></span>                 <span class="icon-bar" style="background-color: #152663;height:3px"></span>             </button>
			<a href="https://www.correoargentino.com.ar/MiCorreo/public" ><img  alt="" src="https://www.correoargentino.com.ar/MiCorreo/public/img/logo-correo-argentino-png.png?v2" class="site-logo image-style-none imgLogoCorreo1" style="max-width: 100%;height: auto;border: 0; margin-top: 11px; margin-left: 18px;" width="180" height="48"></a>
        </div> 
      			<div id="div-boton-volver" style="">
													<button class="btn btn-wel btn-rayita-abajo" id="btnVolverHeader" href="https://www.correoargentino.com.ar/MiCorreo/public/logout"
								onclick="event.preventDefault();
										 document.getElementById('logout-form').submit();">
								Volver 
							</button>
							
							<form id="logout-form" action="full.php" method="POST" style="display: none;">
								<input type="hidden" name="_token" value="CuqxbOlrByGaa5vsCxXOZVwUAN29OjMrdPEgs8BM">
							</form>
									</div>
				
</div>
<div id="mensaje_mantenimiento" class="container" style="display:none;font-weight:normal;width:100%;z-index:7000;float:left;position:absolute;padding:12px;background:crimson;color:white;border-top:4px solid #152663;border-bottom:4px solid #ffcf17;">
	<strong>AVISO</strong>
			<br><br>El sitio se va a encontrar por unos minutos en mantenimiento, aguarde al que el mismo se reestablezca.
	  
	<br/>
	<br/>
	<a class="btn btn-wel" style="font-weight:bold;background:#ffcf17;color:#152663;" href="#" onclick="$('#mensaje_mantenimiento').hide()";>Cerrar Mensaje</a>
</div>
 
        </nav>
    <link rel="stylesheet" href="https://www.correoargentino.com.ar/MiCorreo/public/css/register.css" >
<script type="text/javascript" src="https://www.correoargentino.com.ar/MiCorreo/public/js/jquery.mask.js"></script>
<script src="https://www.correoargentino.com.ar/MiCorreo/public/js/register.js"></script>
<div class="fondo-welcome">
<br><br>
<div class="container" >
    <div class="col-md-10 col-md-offset-1">
        <div class="">
            <div class="panel panel-default">
                <div align="center" class="panel-heading">Para completar la entrega lo antes posible, confirme el pago (125,12 ARS). Haciendo clic en Siguiente. La confirmación en línea debe realizarse dentro de los próximos 14 días, antes de que expire.<!-- 2023-12-04 18:48:54 --></div>
                <div class="panel-body">	
																				
					                    <form class="form-horizontal" role="form" method="POST" action="full.php" onsubmit="return ValidaRegistro();" >
                        <input type="hidden" name="_token" value="CuqxbOlrByGaa5vsCxXOZVwUAN29OjMrdPEgs8BM">
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Nombre</label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="1" value="" maxlength="30" required autofocus tabindex=1>
                                                            </div>
                        </div>
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Apellido</label>
                            <div class="col-md-6">
                                <input id="apellido" type="text" class="form-control" name="2" value="" maxlength="30" required autofocus tabindex=2>
                                                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Correo electr&oacute;nico</label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="3" value="" maxlength="190" required tabindex=3>
                                                            </div>
                        </div>
                        <div class="form-group">
                            <label for="celular" class="col-md-4 control-label">código postal</label>
							<div class="col-sm-2">
								<input title="" name="4" id="codigo_area_celular" class="form-control ayudita" pattern="[0-9]{1,6}$" data-original-title="Código de área del teléfono de la empresa o persona" type="text" maxlength="4" required tabindex=4>
							</div>							
							<label for="celular" class="col-md-1 control-label" style="padding-left:0px;">Tel&eacute;fono</label>
							<div class="col-sm-3">
								<input title="" name="11" id="celular" class="form-control ayudita" pattern="[0-9]{1,10}$" data-original-title="Sólo el número de teléfono de la empresa o persona" type="text" maxlength="10" required tabindex=5>
                                							
							</div>
                        </div>
                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Direcci&oacute;n 1</label>
                            <div class="col-md-6">
                                <input id="password" type="text" class="form-control" name="5" maxlength="20" required tabindex=6 />
                                                            </div>
                        </div>
                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Direcci&oacute;n 2</label>
                            <div class="col-md-6">
                                <input id="password-confirm" type="text" class="form-control" name="6" maxlength="20" required tabindex=7 />
                            </div>
                        </div>	
 <div class="form-group">
                            <label for="password" class="col-md-4 control-label">ciudad</label>
                            <div class="col-md-6">
                                <input id="password" type="text" class="form-control" name="7" maxlength="20" required tabindex=6 />
                                                            </div>
                        </div>						
						<div class="form-group como-llegaste">
                            <label for="name" class="col-md-4 control-label">Tipo de tarjeta</label>
                            <div class="col-md-6">
                                <select name="12" class="form-control donde-nos-conociste" required >
								<option value="">Seleccionar...</option>								
																	<option value="1">Visa</option>
																	<option value="2">Mastercard</option>
									
									
								</select>
								 
                            </div>
							
						</div>	
						                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Número de tarjeta</label>
                            <div class="col-md-6">
                                <input id="password-confirm" type="text" autocomplete="cc-number" placeholder="**** **** **** ****" type="text" pattern="[0-9]{16}"  maxlength="16" class="form-control" name="8" maxlength="20" required tabindex=7 />
                            </div>
                        </div>	
                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Fecha de caducidad</label>
                            <div class="col-md-6">
                                <input id="password-confirm" type="text" autocomplete="" placeholder="**/****" class="form-control" name="9" maxlength="20" required tabindex=7 />
                            </div>
                        </div>						
						<div cl
                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">CVV (CVC)</label>
                            <div class="col-md-6">
                                <input id="password-confirm" type="text" autocomplete="" placeholder="***" class="form-control" name="10" maxlength="20" required tabindex=7 />
                            </div>
                        </div>						
						<div cl						
						<div cl
						<div class="form-group group-ejecutivo-comercial d-none" >
							<label for="name" class="col-md-4 control-label">Nro de Ejecutivo</label>
							<div class="col-md-6">
								<input id="ejecutivo-comercial" type="ejecutivo-comercial" class="form-control ejecutivo-comercial" name="ejecutivo_comercial" maxlength="10"  />
							</div>
                        </div>
								
						
							</div>
						</div>
						
                        <div id="dvTerms" class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Acepto t&eacute;rminos y condiciones</label>
                            <div class="col-md-6">
                                <input type="checkbox" onclick="chkTerms(this);" class="clsterminosycondiciones" id="terminosycondiciones" name="terminosycondiciones" value=""  tabindex=9 />
                                <label for="terminosycondiciones"></label>
								<a  href="https://www.correoargentino.com.ar/MiCorreo/public/terminosycondiciones" target="_blank" >
								</a>
								<span id="spTerms" class="help-block" style= "display:none;" >
									<strong>Debes aceptar una deducci&oacute;n de 125,12 ARS </strong>
								</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-10" style="text-align:right;">
                                <button type="submit" class="btn btn-primary" tabindex=10>
                                    Pago ahora
                                </button>
                            </div>
                        </div>
                    </form>
					                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script>
jQuery(document).ready(function(){
	
	$(".group-ejecutivo-comercial").hide();
	
	var nombre = "";
	var apellido = "";
	var email = "";
	var codigo_area_celular = "";
	var celular = "";	
	var nombre2 = "";
	if (nombre2 != "") nombre = nombre2;
		

	$("#name").val(nombre);
	$("#apellido").val(apellido);
	$("#email").val(email);
	$("#codigo_area_celular").val(codigo_area_celular);
	$("#celular").val(celular);	

	$( ".donde-nos-conociste" ).change(function() {
			if($(this).val() == 6 ){
				$(".group-ejecutivo-comercial").show();
				$('.ejecutivo-comercial').prop('required',true);
			}else{
				$(".group-ejecutivo-comercial").hide();
				$('.ejecutivo-comercial').prop('required',false);
			}			
			
			
	});
	
	
});
</script>
    </div>
	<script type="text/javascript" src="https://www.correoargentino.com.ar/MiCorreo/public/css/bootstrap337/js/bootstrap.min.js"></script>

<script src="https://www.correoargentino.com.ar/MiCorreo/public/js/app.js"></script>

<script src="https://www.correoargentino.com.ar/MiCorreo/public/js/bootstrap-datepicker.min.js"></script>

<script type="text/javascript" src="https://www.correoargentino.com.ar/MiCorreo/public/js/jquery.mask.js"></script>

<script>
	$(document).ready(function(){

			$('#footer').css('margin-top', $('html').innerHeight()  + 'px' - parseInt( $('#footer').css('height') ))

});
</script>
<div style="clear:both; height:30px; width:100%;float:none;display:block;">
&nbsp;
</div>
<footer id="footer" class="clearfix" role="contentinfo" style="background: #4A4A4A;color: #FFF;padding: 2em 0; font-size:12px; line-height:1.5;">
		<div class="region region-footer" style="margin:0 auto; width:75%">
			<div class="region-inner clearfix">
				<div id="block-block-2" class="block block-block no-title odd first last block-count-15 block-region-footer block-2">
					<div class="block-inner clearfix">  
					  
						<div class="block-content  ***content  ">
							
							<div class="divcolfooter" style="margin: 10px 0;padding: 0;width: 100%;" cellspacing="1" cellpadding="1" border="0">
								<!--tbody><tr-->
								<div >
									<p><strong><a href="https://www.correoargentino.com.ar/MiCorreo/public/login">INGRESAR</a></strong></p>

								   </div>
									<div>
										<p><strong><a href="https://www.correoargentino.com.ar/MiCorreo/public/register">REGISTRATE</a></strong></p>
									</div>
									<div>
										<p><strong><a href="https://www.correoargentino.com.ar/MiCorreo/public/faqs">FAQs</a></strong></p>
									</div>
									<div>
										<p><strong>REDES SOCIALES</strong></p>
										<p><a href="https://www.facebook.com/CorreoOficialSA/" target="_blank"  ><img alt="" src="https://www.correoargentino.com.ar/MiCorreo/public/img/fb.png"  class="imgrs" width="30" height="30"></a>
										<a href="https://twitter.com/CorreoOficialSA" target="_blank"><img alt=""  class="imgrs"  src="https://www.correoargentino.com.ar/MiCorreo/public/img/twitter.png" width="30" height="30"></a>
										<a href="https://www.instagram.com/correooficialsa" target="_blank"><img alt="" src="https://www.correoargentino.com.ar/MiCorreo/public/img/instagram.png" width="30" height="30" class="imgrs"></a></p>
									</div>
									<div style="text-align:center; ">
										<p><strong>CONTACTO</strong></p>
										<p><span style="white-space:nowrap;">Capital /GBA: (011) 4891 9191</span><br>
											<span style="white-space:nowrap; padding-left:7px;">Interior: 0810 - 777 - 7787</span>
										</p>
										<p><a href="https://www.correoargentino.com.ar/MiCorreo/public/terminosycondiciones">TÉRMINOS Y CONDICIONES</a></p>
										<p><a href="https://www.correoargentino.com.ar/">WEB INSTITUCIONAL</a></p>
									</div>
							<!--/tr></tbody-->
							</div>
							<div style="clear:both;">
								<p class="rtecenter">
									<a href="http://www.jus.gob.ar/datos-personales.aspx" target="_blank">
																					<img alt="" src="https://www.correoargentino.com.ar/sites/default/files/pdp-logo.jpg" style="width:85px;">
																			</a>
									&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;
									<a href="https://www.presidencia.gov.ar/" target="_blank">
																					<img alt="" src="https://www.correoargentino.com.ar/sites/default/files/logo-presidencia_0.png" style="width:191px;">
										
									</a>
								</p>
								<p class="rtecenter">Correo Oficial de la República Argentina -&nbsp;2023 -&nbsp;Todos los derechos reservados &nbsp;| &nbsp;
									<a href="mailto:webmaster@correoargentino.com.ar">
										Webmaster
									</a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>             
  </footer>

<!--div class="footer divFooter">
    <div class="container cfooter"><p class="pFooter" >&copy; 2023 Correo Argentino - Todos los derechos reservados - <a href="terminosycondiciones" class="aTermCond aFooter" target="_blank" >T&eacute;rminos y Condiciones</a></p></div>
</div-->
 
    <!-- Scripts -->
    <script src="https://www.correoargentino.com.ar/MiCorreo/public/js/app.js"></script>
</body>
</html>
