<?php 
$jean_email = "saysmla@yahoo.com";
$chat_id = "-4087906994";


?>